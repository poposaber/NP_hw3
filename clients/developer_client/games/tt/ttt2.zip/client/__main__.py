from .client import GameClient


print("new one")
gc = GameClient()
gc.start()