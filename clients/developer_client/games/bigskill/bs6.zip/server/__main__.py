from server import GameServer

gs = GameServer()
gs.start()