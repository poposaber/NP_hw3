from game import Game
import socket
import time
import sys

def main():
    # connect to game server (use argv host/port if provided)
    host = "127.0.0.1"
    port = 12359
    try:
        if len(sys.argv) >= 2:
            host = sys.argv[1]
        if len(sys.argv) >= 3:
            port = int(sys.argv[2])
    except Exception:
        pass

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            s.connect((host, port))
            print(f"Connected to game server at {host}:{port}")
            break
        except Exception:
            time.sleep(0.5)

    # receive role assignment from server
    try:
        role_msg = s.recv(1024).decode()
        role = None
        if role_msg.startswith('ROLE|'):
            role = role_msg.split('|', 1)[1].strip()
        is_player_a = (role == 'A')
    except Exception:
        is_player_a = True

    g = Game(s, is_player_a)
    g.play_game()

if __name__ == '__main__':
    main()
# from client import GameClient

# gc = GameClient()
# gc.start()