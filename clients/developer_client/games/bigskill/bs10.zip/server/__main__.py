import importlib.util
from pathlib import Path

try:
	# Load server.py from same directory robustly whether executed as script or via module
	p = Path(__file__).resolve().parent / "server.py"
	spec = importlib.util.spec_from_file_location("bigskill_server", str(p))
	mod = importlib.util.module_from_spec(spec)
	spec.loader.exec_module(mod)  # type: ignore
	GameServer = getattr(mod, "GameServer")
except Exception:
	# fallback to direct import
	from server import GameServer

if __name__ == '__main__':
	import sys
	port = None
	try:
		if len(sys.argv) >= 2:
			port = int(sys.argv[1])
	except Exception:
		port = None
	if port:
		gs = GameServer(port=port)
	else:
		gs = GameServer()
	gs.start()