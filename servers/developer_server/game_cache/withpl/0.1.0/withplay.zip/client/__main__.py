from .client import GameClient

gc = GameClient()
gc.start()